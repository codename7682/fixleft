$(document).ready(function(){
    
    var artlen = $("article").length;
    var h;
    
    function setsize(){
//        $("#container").height($("section").height());
        h = $("body").height() - $(window).height();
        var eh = h / artlen;
        var scr = $(document).scrollTop();
        var artnum = Math.floor(scr/eh);
        if(artnum >= artlen){artnum = artlen - 1;}
//        console.log(Math.floor(scr/eh));
        
        var title = $("article").eq(artnum).attr("data-title");
        var cont = $("article").eq(artnum).attr("data-cont");
        var url = $("article").eq(artnum).attr("data-url");
        
        $("#cardbot>h3").text(title);
        $("#cardbot>p").text(cont);
        $("#cardbot>a").attr("href",url);
    }
    
    $(window).resize(function(){setsize();});
    $(window).scroll(function(){setsize();});
    
});